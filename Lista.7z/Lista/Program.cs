﻿using System;

namespace ListaExercicio
{
    class Program
    {
        static void Main(string[] args)
        {                   //toda vez que eu chamo um método, ele é seguido de parenteses
            Console.WriteLine("Hello World!");
                            //Console.writeline == Imprimir mensagem no terminal
            // Exe01.renderizar();

            // Exe02.renderizar();

            // Exe03.renderizar();

            Exe04.renderizar();

        

        }
    }
}
