using System;
    namespace ListaExercicio
    {
        class Exe06
        {
            public static void renderizar()
            {
                    /* Desenvolver um algoritmo para receber 1000 valores automaticamente dentro deum vetor e ordenar do menor para o maior
                    .a) Desenvolver o algoritmo de ordenação;b) Utilizar uma função em C# para ordenação;*/


            }
        }
    }