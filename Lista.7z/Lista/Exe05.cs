using System;
    namespace ListaExercicio
    {
        class Exe05
        {
            public static void renderizar()
            {
                    /*Criar um algoritmo que receba um valor positivo inteiro e imprima a sequênciaFibonacci até o valor lido.
                     Por exemplo: caso o usuário insira o número 15, oprograma deve imprimir na tela os números 0, 1, 1, 2, 3, 5, 8, 13. */

                Console.WriteLine("Exercicio 05");
                Console.WriteLine("Informe o número desejado");

            }
        }
    }